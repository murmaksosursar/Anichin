const website_name = "JustAnime";

export default website_name;